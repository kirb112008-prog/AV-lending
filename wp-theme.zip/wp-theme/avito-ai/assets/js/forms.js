(function () {
  'use strict';

  document.querySelectorAll('.faq__item').forEach(function (item) {
    var button = item.querySelector('.faq__question');
    var panel = item.querySelector('.faq__panel');

    if (!button || !panel) return;

    button.addEventListener('click', function () {
      var opening = !item.classList.contains('faq__item--open');

      document.querySelectorAll('.faq__item').forEach(function (other) {
        var otherButton = other.querySelector('.faq__question');
        var otherPanel = other.querySelector('.faq__panel');
        var isThis = other === item;
        var open = isThis && opening;

        other.classList.toggle('faq__item--open', open);
        if (otherButton) otherButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (otherPanel) otherPanel.setAttribute('aria-hidden', open ? 'false' : 'true');
      });
    });
  });

  var calculator = document.querySelector('[data-calculator]');

  if (calculator) {
    var inputs = calculator.querySelectorAll('input');
    var MAX_LOSS_RATE = 0.6;
    var LOSS_RATE_PER_MINUTE = 0.4 / 15;
    var RECOVERABLE_SHARE = 0.75;

    var format = function (value) {
      return Math.round(value).toLocaleString('ru-RU');
    };

    var read = function (name) {
      var input = calculator.querySelector('input[name="' + name + '"]');
      var value = parseFloat(String(input.value).replace(/\s/g, '').replace(',', '.'));
      return isNaN(value) || value < 0 ? 0 : value;
    };

    var update = function () {
      var requests = read('requestsPerMonth');
      var check = read('averageCheck');
      var minutes = read('responseMinutes');
      var conversion = read('conversionPercent');

      var lossRate = Math.min(MAX_LOSS_RATE, minutes * LOSS_RATE_PER_MINUTE);
      var lostRequests = Math.round(requests * lossRate);
      var lostRevenue = Math.round(lostRequests * (conversion / 100) * check);
      var recoverable = Math.round(lostRevenue * RECOVERABLE_SHARE);

      var results = {
        lostRequests: lostRequests,
        lostRevenue: lostRevenue,
        recoverableRevenue: recoverable
      };

      calculator.querySelectorAll('[data-result]').forEach(function (node) {
        var key = node.getAttribute('data-result');
        node.textContent =
          (node.getAttribute('data-prefix') || '') + format(results[key]) + (node.getAttribute('data-suffix') || '');
      });
    };

    inputs.forEach(function (input) {
      input.addEventListener('input', update);
    });
  }

  var phone = document.querySelector('[data-phone-mask]');

  if (phone) {
    phone.addEventListener('input', function () {
      var digits = phone.value.replace(/\D/g, '');
      if (digits.charAt(0) === '7' || digits.charAt(0) === '8') digits = digits.slice(1);
      digits = digits.slice(0, 10);
      var out = '';
      if (digits) {
        out = '+7 (' + digits.slice(0, 3);
        if (digits.length >= 3) out += ')';
        if (digits.length > 3) out += ' ' + digits.slice(3, 6);
        if (digits.length > 6) out += '-' + digits.slice(6, 8);
        if (digits.length > 8) out += '-' + digits.slice(8, 10);
      }
      phone.value = out;
    });
  }

  var form = document.querySelector('[data-cta-form]');

  if (form) {
    var button = form.querySelector('[data-submit], .cta__button');
    var defaultLabel = form.getAttribute('data-label') || button.textContent;

    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

    var showError = function (name, message) {
      var holder = form.querySelector('[data-error-for="' + name + '"]');
      var control = form.elements[name];

      if (holder) {
        holder.textContent = message || '';
        holder.hidden = !message;
      }

      if (control) {
        if (message) {
          control.setAttribute('aria-invalid', 'true');
        } else {
          control.removeAttribute('aria-invalid');
        }
      }
    };

    var validate = function (values) {
      var digits = values.phone.replace(/\D/g, '');
      if (digits.charAt(0) === '7' || digits.charAt(0) === '8') digits = digits.slice(1);

      var nameHolder = form.querySelector('[data-error-for="name"]');
      var nameLabel = (nameHolder && nameHolder.getAttribute('data-label')) || 'имя';
      var errors = {};

      if (values.name.length < 2) errors.name = 'Укажите ' + nameLabel;
      if (!emailPattern.test(values.email)) errors.email = 'Введите email в формате name@mail.ru';
      if (digits.length !== 10) errors.phone = 'Введите номер полностью: +7 (900) 000-00-00';
      if (!values.niche) errors.niche = 'Выберите нишу';

      ['name', 'email', 'phone', 'niche'].forEach(function (name) {
        showError(name, errors[name]);
      });

      var first = ['name', 'email', 'phone', 'niche'].filter(function (name) {
        return errors[name];
      })[0];

      if (first && form.elements[first]) form.elements[first].focus();

      return !first;
    };

    ['input', 'change'].forEach(function (type) {
      form.addEventListener(type, function (event) {
        if (event.target && event.target.name) showError(event.target.name, '');
      });
    });

    var setState = function (label, disabled) {
      button.textContent = label;
      button.disabled = disabled;
    };

    form.addEventListener('submit', function (event) {
      event.preventDefault();

      var values = {
        name: String(form.elements.name.value || '').trim(),
        email: String(form.elements.email.value || '').trim(),
        phone: String(form.elements.phone.value || '').trim(),
        niche: form.elements.niche.value || ''
      };

      if (!validate(values)) {
        return;
      }

      var endpoint = form.getAttribute('data-endpoint');
      var redirect = form.getAttribute('data-redirect');

      if (!endpoint) {
        setState('Форма не настроена', true);
        return;
      }

      setState('Одну секунду...', true);

      fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer 8d916e2c-8a5e-4567-824f-d84af16a102d'
        },
        body: JSON.stringify(values)
      })
        .then(function (response) {
          if (response.status === 200) {
            setState('Заявка успешно отправлена!', true);
            if (redirect) window.location.href = redirect;
          } else {
            setState('Что-то пошло не так, перезагрузите страницу и попробуйте снова', true);
          }
        })
        .catch(function () {
          setState('Что-то пошло не так, перезагрузите страницу и попробуйте снова', true);
        });
    });

    form.setAttribute('data-default-label', defaultLabel);
  }
})();
