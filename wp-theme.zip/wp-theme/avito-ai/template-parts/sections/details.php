<?php
if (!defined('ABSPATH')) {
    exit;
}
$columns = $section['columns'] ?? [];
?>
<section id="details" class="details section">
  <div class="container details__container">
    <h2 class="details__title"><?php avito_rich_e($section['title'] ?? '', 'details'); ?></h2>

    <?php if ($columns) : ?>
      <ul class="details__columns">
        <?php foreach ($columns as $column) : ?>
          <li class="details-column">
            <span class="details-column__icon"><?php echo avito_icon_svg($column['icon'] ?? ''); ?></span>
            <h3 class="details-column__title"><?php echo esc_html($column['title'] ?? ''); ?></h3>
            <ul class="details-column__items">
              <?php foreach (avito_list($column['items'] ?? '') as $line) : ?>
                <li><?php echo esc_html($line); ?></li>
              <?php endforeach; ?>
            </ul>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <?php if (!empty($section['button_label'])) : ?>
      <a href="<?php echo esc_url($section['button_href'] ?? '#contact'); ?>" class="details__cta"><?php echo esc_html($section['button_label']); ?></a>
    <?php endif; ?>
  </div>
</section>
